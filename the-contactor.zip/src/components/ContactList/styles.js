import { StyleSheet} from 'react-native';

export default StyleSheet.create({
  container: {
    backgroundColor: 'black'
  },
  row: {
    backgroundColor: '#171616',
    textAlign: 'left'
  },
});
