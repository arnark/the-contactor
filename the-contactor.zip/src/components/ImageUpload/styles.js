import { StyleSheet} from 'react-native';

export default StyleSheet.create({
  image: {
    width: 125,
    height: 125,
    margin: 10
  },
  imageUploadContainer: {
    alignItems: 'center',
    justifyContent: 'center'
  }
});
